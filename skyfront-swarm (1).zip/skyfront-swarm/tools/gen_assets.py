#!/usr/bin/env python3
"""Generates the GLB models + pixel textures for Skyfront: Swarm.

Models follow Skyfront's own GLB convention (see skyfront bb2glb):
  node "airframe" (mesh) [+ node "prop1" with Molniya-style 90deg-X rotation],
  one material "texture" with NEAREST sampler, nose toward -Z, +Y up.

usage: python3 gen_assets.py <skyfront.jar> <out assets/skyfront_swarm dir>
"""
import io, json, math, struct, sys, zipfile, random
import numpy as np
from PIL import Image, ImageDraw

ATLAS = 128
# atlas regions (x0, y0, x1, y1) in pixels
R = dict(fus=(0, 0, 64, 24), nose=(64, 0, 128, 24), wtop=(0, 24, 64, 88), wbot=(64, 24, 128, 88),
         fin=(0, 88, 32, 120), prop=(32, 88, 48, 96), eng=(64, 88, 96, 120), dark=(96, 88, 128, 120))

# ---------------------------------------------------------------- geometry
class Mesh:
    def __init__(self): self.p = []; self.n = []; self.uv = []; self.i = []
    def tri(self, a, b, c, uva, uvb, uvc):
        a, b, c = map(np.array, (a, b, c))
        nrm = np.cross(b - a, c - a); l = np.linalg.norm(nrm)
        nrm = nrm / l if l > 1e-9 else np.array([0, 1, 0])
        base = len(self.p)
        for v, uv in ((a, uva), (b, uvb), (c, uvc)):
            self.p.append(v); self.n.append(nrm); self.uv.append(uv)
        self.i += [base, base + 1, base + 2]
    def quad(self, a, b, c, d, region, flip=False, uvs=None):
        x0, y0, x1, y1 = R[region]
        e = 0.5
        u0, u1 = (x0 + e) / ATLAS, (x1 - e) / ATLAS
        v0, v1 = (y0 + e) / ATLAS, (y1 - e) / ATLAS
        uvq = uvs or [(u0, v0), (u1, v0), (u1, v1), (u0, v1)]
        if flip: a, b, c, d = a, d, c, b; uvq = [uvq[0], uvq[3], uvq[2], uvq[1]]
        self.tri(a, b, c, uvq[0], uvq[1], uvq[2]); self.tri(a, c, d, uvq[0], uvq[2], uvq[3])

def region_uv(region, fx, fy):
    x0, y0, x1, y1 = R[region]; e = 0.5
    return ((x0 + e + (x1 - x0 - 2 * e) * fx) / ATLAS, (y0 + e + (y1 - y0 - 2 * e) * fy) / ATLAS)

def box(m, x0, x1, y0, y1, z0, z1, region):
    P = lambda x, y, z: (x, y, z)
    m.quad(P(x0, y1, z0), P(x1, y1, z0), P(x1, y1, z1), P(x0, y1, z1), region)            # top
    m.quad(P(x0, y0, z0), P(x0, y0, z1), P(x1, y0, z1), P(x1, y0, z0), region)            # bottom
    m.quad(P(x0, y0, z0), P(x1, y0, z0), P(x1, y1, z0), P(x0, y1, z0), region, flip=True) # front(-z)
    m.quad(P(x0, y0, z1), P(x0, y1, z1), P(x1, y1, z1), P(x1, y0, z1), region, flip=True) # back
    m.quad(P(x0, y0, z0), P(x0, y1, z0), P(x0, y1, z1), P(x0, y0, z1), region, flip=True) # left
    m.quad(P(x1, y0, z0), P(x1, y0, z1), P(x1, y1, z1), P(x1, y1, z0), region, flip=True) # right

def loft(m, rings, sides=8, yc=0.1, regions=None):
    """rings: list of (z, rx, ry). Smooth-ish lofted tube along Z, nose first."""
    pts = []
    for z, rx, ry in rings:
        pts.append([(rx * math.cos(2 * math.pi * k / sides), yc + ry * math.sin(2 * math.pi * k / sides), z) for k in range(sides)])
    for s in range(len(rings) - 1):
        reg = regions[s] if regions else 'fus'
        for k in range(sides):
            k2 = (k + 1) % sides
            a, b, c, d = pts[s][k], pts[s][k2], pts[s + 1][k2], pts[s + 1][k]
            u0 = s / (len(rings) - 1); u1 = (s + 1) / (len(rings) - 1)
            f0, f1 = k / sides, (k + 1) / sides
            uvq = [region_uv(reg, 0, f0), region_uv(reg, 0, f1), region_uv(reg, 1, f1), region_uv(reg, 1, f0)]
            m.quad(a, b, c, d, reg, uvs=uvq)
    # caps
    for idx, rev in ((0, True), (len(rings) - 1, False)):
        z, rx, ry = rings[idx]; cen = (0, yc, z)
        for k in range(sides):
            k2 = (k + 1) % sides
            a, b = pts[idx][k], pts[idx][k2]
            uvc = region_uv('dark', 0.5, 0.5)
            if rev: m.tri(cen, b, a, uvc, uvc, uvc)
            else: m.tri(cen, a, b, uvc, uvc, uvc)

def slab(m, poly, y0, y1, top_reg, bot_reg):
    """convex polygon in XZ extruded between y0..y1 (flat wing)."""
    xs = [p[0] for p in poly]; zs = [p[1] for p in poly]
    def uv(reg, x, z):
        fx = (x - min(xs)) / max(1e-6, max(xs) - min(xs)); fy = (z - min(zs)) / max(1e-6, max(zs) - min(zs))
        return region_uv(reg, fx, fy)
    c = (sum(xs) / len(xs), sum(zs) / len(zs))
    n = len(poly)
    for k in range(n):
        a, b = poly[k], poly[(k + 1) % n]
        m.tri((c[0], y1, c[1]), (b[0], y1, b[1]), (a[0], y1, a[1]), uv(top_reg, *c), uv(top_reg, *b), uv(top_reg, *a))
        m.tri((c[0], y0, c[1]), (a[0], y0, a[1]), (b[0], y0, b[1]), uv(bot_reg, *c), uv(bot_reg, *a), uv(bot_reg, *b))
        e0, e1 = (a[0], y0, a[1]), (b[0], y0, b[1]); e2, e3 = (b[0], y1, b[1]), (a[0], y1, a[1])
        m.quad(e0, e1, e2, e3, 'fin')

# ---------------------------------------------------------------- glb io
def pack_glb(meshes, nodes, png_bytes, path):
    """meshes: list of (name, Mesh). nodes: list of dict (name, mesh idx, optional translation/rotation)."""
    blob = bytearray(); views = []; accessors = []; gm = []
    def add_view(data, target=None):
        while len(blob) % 4: blob.append(0)
        off = len(blob); blob.extend(data)
        v = {"buffer": 0, "byteOffset": off, "byteLength": len(data)}
        if target: v["target"] = target
        views.append(v); return len(views) - 1
    for name, m in meshes:
        P = np.array(m.p, dtype='<f4'); N = np.array(m.n, dtype='<f4'); U = np.array(m.uv, dtype='<f4'); I = np.array(m.i, dtype='<u2')
        a = []
        for arr, typ, tgt, cnt in ((P, "VEC3", 34962, len(P)), (N, "VEC3", 34962, len(P)), (U, "VEC2", 34962, len(P))):
            acc = {"bufferView": add_view(arr.tobytes(), tgt), "componentType": 5126, "count": cnt, "type": typ}
            if typ == "VEC3" and arr is P: acc["min"] = [float(x) for x in P.min(0)]; acc["max"] = [float(x) for x in P.max(0)]
            accessors.append(acc); a.append(len(accessors) - 1)
        accessors.append({"bufferView": add_view(I.tobytes(), 34963), "componentType": 5123, "count": len(I), "type": "SCALAR"}); a.append(len(accessors) - 1)
        gm.append({"name": name, "primitives": [{"attributes": {"POSITION": a[0], "NORMAL": a[1], "TEXCOORD_0": a[2]}, "indices": a[3], "material": 0, "mode": 4}]})
    img_view = add_view(png_bytes)
    js = {"asset": {"version": "2.0", "generator": "skyfront-swarm gen_assets"}, "scene": 0,
          "scenes": [{"nodes": list(range(len(nodes)))}], "nodes": nodes, "meshes": gm,
          "buffers": [{"byteLength": len(blob)}], "bufferViews": views, "accessors": accessors,
          "materials": [{"name": "texture", "pbrMetallicRoughness": {"baseColorTexture": {"index": 0}, "metallicFactor": 0.0, "roughnessFactor": 1.0}, "alphaMode": "MASK", "alphaCutoff": 0.5, "doubleSided": True}],
          "textures": [{"sampler": 0, "source": 0}], "images": [{"bufferView": img_view, "mimeType": "image/png", "name": "texture"}],
          "samplers": [{"magFilter": 9728, "minFilter": 9728, "wrapS": 33071, "wrapT": 33071}]}
    write_glb(js, bytes(blob), path)

def write_glb(js, blob, path):
    js["buffers"][0]["byteLength"] = len(blob)
    j = json.dumps(js, separators=(',', ':')).encode()
    while len(j) % 4: j += b' '
    b = bytes(blob)
    while len(b) % 4: b += b'\0'
    out = b'glTF' + struct.pack('<II', 2, 12 + 8 + len(j) + 8 + len(b)) + struct.pack('<I', len(j)) + b'JSON' + j + struct.pack('<I', len(b)) + b'BIN\0' + b
    open(path, 'wb').write(out)

def read_glb(data):
    l = struct.unpack('<I', data[12:16])[0]; js = json.loads(data[20:20 + l]); off = 20 + l
    bl = struct.unpack('<I', data[off:off + 4])[0]; return js, data[off + 8:off + 8 + bl]

def swap_texture(js, blob, new_png):
    """replace the embedded PNG, repacking bufferViews."""
    img_bv = js['images'][0]['bufferView']; out = bytearray()
    for i, bv in enumerate(js['bufferViews']):
        data = new_png if i == img_bv else blob[bv.get('byteOffset', 0):bv.get('byteOffset', 0) + bv['byteLength']]
        while len(out) % 4: out.append(0)
        bv['byteOffset'] = len(out); bv['byteLength'] = len(data); out.extend(data)
    return js, bytes(out)

# ---------------------------------------------------------------- textures
def noise_fill(img, box_, base, var, rng, speck=None, rust=None):
    x0, y0, x1, y1 = box_
    for y in range(y0, y1):
        for x in range(x0, x1):
            d = rng.randint(-var, var)
            c = tuple(max(0, min(255, base[k] + d)) for k in range(3))
            if rust and rng.random() < 0.06: c = tuple(max(0, min(255, rust[k] + rng.randint(-8, 8))) for k in range(3))
            if speck and rng.random() < 0.02: c = speck
            img.putpixel((x, y), c + (255,))

def paint(pal, seed):
    rng = random.Random(seed)
    img = Image.new('RGBA', (ATLAS, ATLAS), (0, 0, 0, 0)); dr = ImageDraw.Draw(img)
    noise_fill(img, R['fus'], pal['body'], 10, rng, rust=pal.get('rust'))
    noise_fill(img, R['nose'], pal['nose'], 8, rng, rust=pal.get('rust'))
    noise_fill(img, R['wtop'], pal['wing'], 9, rng, rust=pal.get('rust'))
    noise_fill(img, R['wbot'], pal['belly'], 8, rng)
    noise_fill(img, R['fin'], pal['fin'], 8, rng)
    noise_fill(img, R['prop'], (24, 24, 26), 5, rng)
    noise_fill(img, R['eng'], pal['engine'], 10, rng, rust=(120, 70, 40))
    noise_fill(img, R['dark'], (28, 28, 30), 4, rng)
    # camo blotches on wing top / fuselage
    if pal.get('camo'):
        for reg in ('wtop', 'fus'):
            x0, y0, x1, y1 = R[reg]
            for _ in range(10 if reg == 'wtop' else 5):
                cx, cy = rng.randint(x0, x1), rng.randint(y0, y1); rw, rh = rng.randint(6, 16), rng.randint(3, 8)
                dr.ellipse([cx - rw, cy - rh, cx + rw, cy + rh], fill=pal['camo'] + (255,))
            # re-clip: repaint outside region from neighbours is skipped; ellipses are small enough, mask below
        # restore areas bled outside regions
        for reg in R:
            pass
    # panel lines
    line = tuple(max(0, c - 38) for c in pal['body'])
    x0, y0, x1, y1 = R['fus']
    for x in range(x0 + 8, x1, 10): dr.line([(x, y0), (x, y1 - 1)], fill=line + (255,))
    for y in range(y0 + 8, y1, 8): dr.line([(x0, y), (x1 - 1, y)], fill=line + (255,))
    x0, y0, x1, y1 = R['wtop']
    for y in range(y0 + 10, y1, 14): dr.line([(x0, y), (x1 - 1, y)], fill=tuple(max(0, c - 30) for c in pal['wing']) + (255,))
    dr.line([(x0, y0 + 1), (x1 - 1, y0 + 1)], fill=pal['accent'] + (255,))
    # warhead band + stripes on nose
    x0, y0, x1, y1 = R['nose']
    dr.rectangle([x0 + 20, y0, x0 + 27, y1 - 1], fill=pal['accent'] + (255,))
    dr.rectangle([x0 + 30, y0, x0 + 32, y1 - 1], fill=pal['accent'] + (255,))
    # fin markings
    x0, y0, x1, y1 = R['fin']
    dr.rectangle([x0 + 2, y0 + 2, x0 + 13, y0 + 9], fill=pal['accent'] + (255,))
    for k in range(4): dr.line([(x0 + 2 + k * 3, y0 + 3), (x0 + k * 3, y0 + 10)], fill=(20, 20, 20, 255))
    # little 'stencil' blocks to mimic Skyfront's pixel stencils
    x0, y0, x1, y1 = R['wbot']
    for k in range(6): dr.rectangle([x0 + 4 + k * 9, y0 + 30, x0 + 8 + k * 9, y0 + 33], outline=(210, 210, 215, 255))
    return img

def png_bytes(img):
    b = io.BytesIO(); img.save(b, 'PNG'); return b.getvalue()

PAL = {
    's131': dict(body=(196, 178, 134), nose=(120, 104, 74), wing=(190, 170, 124), belly=(214, 202, 170), fin=(150, 132, 96), engine=(70, 66, 60), accent=(190, 60, 40), camo=(158, 136, 92), rust=(150, 100, 60)),
    's136': dict(body=(178, 182, 186), nose=(84, 88, 94), wing=(168, 172, 178), belly=(206, 208, 212), fin=(120, 124, 130), engine=(60, 62, 66), accent=(210, 170, 40), rust=(140, 96, 70)),
    's238': dict(body=(84, 90, 100), nose=(46, 50, 58), wing=(74, 80, 90), belly=(110, 116, 124), fin=(60, 64, 72), engine=(66, 70, 78), accent=(70, 170, 220), rust=(110, 80, 60)),
    's149': dict(body=(98, 108, 72), nose=(60, 66, 44), wing=(92, 102, 66), belly=(150, 156, 128), fin=(70, 78, 52), engine=(54, 56, 50), accent=(226, 196, 40), camo=(66, 78, 48), rust=(120, 90, 50)),
}

# ---------------------------------------------------------------- aircraft builder
def build_plane(span, length, apex_frac, tip_back, jet, heavy=False):
    L = length / 2; m = Mesh(); pm = Mesh()
    # delta wing: apex ahead, tips at trailing edge
    apex_z = -L + length * apex_frac; tail_z = L - 0.25
    poly = [(0.0, apex_z), (span, tail_z - tip_back), (span, tail_z), (-span, tail_z), (-span, tail_z - tip_back)]
    # order convex polygon CCW viewed from +Y: reorder
    poly = [(0.0, apex_z), (-span, tail_z - tip_back), (-span, tail_z), (span, tail_z), (span, tail_z - tip_back)]
    slab(m, poly, 0.0, 0.045, 'wtop', 'wbot')
    # winglets (vertical fins at the tips, slightly cant-less)
    for sx in (-1, 1):
        x = sx * span
        box(m, min(x, x - sx * 0.04), max(x, x - sx * 0.04), -0.12, 0.34, tail_z - 0.5, tail_z, 'fin')
    # fuselage
    r = 0.13 if not heavy else 0.17
    rings = [(-L, 0.015, 0.015), (-L + 0.22, r * 0.55, r * 0.55), (-L + 0.55, r, r), (L - 0.55, r, r), (L - 0.12, r * 0.8, r * 0.8), (L, r * 0.7, r * 0.7)]
    loft(m, rings, sides=8, yc=0.11, regions=['nose', 'nose', 'fus', 'fus', 'eng'])
    if jet:
        # dorsal intake + engine pod
        box(m, -0.10, 0.10, 0.22, 0.34, -0.1, 0.55, 'eng')
        box(m, -0.13, 0.13, 0.05, 0.28, L - 0.7, L + 0.18, 'eng')
        box(m, -0.07, 0.07, 0.11, 0.21, L + 0.18, L + 0.30, 'dark')
    else:
        # pusher motor + hub
        box(m, -0.10, 0.10, 0.02, 0.22, L, L + 0.20, 'eng')
    nodes = [{"name": "airframe", "mesh": 0}]; meshes = [("airframe", m)]
    if not jet:
        rad = span * 0.33 if not heavy else span * 0.30
        box(pm, -rad, rad, -0.02, 0.02, -0.035, 0.035, 'prop')
        meshes.append(("prop1", pm))
        nodes.append({"name": "prop1", "mesh": 1, "translation": [0.0, 0.12, L + 0.24], "rotation": [0.7071067811865476, 0.0, 0.0, 0.7071067811865476]})
    return meshes, nodes

# ---------------------------------------------------------------- fpv recolours
def tint_texture(png, hue_shift, sat_mul, grey_tint, val_mul=1.0):
    im = Image.open(io.BytesIO(png)).convert('RGBA'); a = im.split()[3]
    hsv = np.array(im.convert('RGB').convert('HSV')).astype(np.int32)
    colored = hsv[..., 1] > 70
    hsv[..., 0] = np.where(colored, (hsv[..., 0] + hue_shift) % 256, hsv[..., 0])
    hsv[..., 1] = np.where(colored, np.clip(hsv[..., 1] * sat_mul, 0, 255), hsv[..., 1])
    rgb = np.array(Image.fromarray(hsv.astype(np.uint8), 'HSV').convert('RGB')).astype(np.float32)
    grey = (hsv[..., 1] <= 70)[..., None]
    t = np.array(grey_tint, dtype=np.float32) / 255.0
    rgb = np.where(grey, rgb * t, rgb) * val_mul
    out = Image.fromarray(np.clip(rgb, 0, 255).astype(np.uint8), 'RGB').convert('RGBA'); out.putalpha(a)
    return png_bytes(out)

def main():
    jar, out = sys.argv[1], sys.argv[2]
    import os
    os.makedirs(f'{out}/models/entity', exist_ok=True); os.makedirs(f'{out}/textures/entity', exist_ok=True)
    # --- shaheds
    specs = [('shahed_131', 's131', build_plane(0.95, 2.3, 0.18, 0.55, False)),
             ('shahed_136_pilot', 's136', build_plane(1.2, 3.0, 0.12, 0.8, False)),
             ('shahed_238_pilot', 's238', build_plane(0.9, 3.3, 0.10, 0.9, True)),
             ('shahed_149', 's149', build_plane(1.55, 3.6, 0.14, 0.95, False, heavy=True))]
    for i, (name, pal, (meshes, nodes)) in enumerate(specs):
        img = paint(PAL[pal], 100 + i); png = png_bytes(img)
        pack_glb(meshes, nodes, png, f'{out}/models/entity/{name}.glb')
        img.save(f'{out}/textures/entity/{name}.png')
    # --- fpv recolours from skyfront's own fpv.glb
    z = zipfile.ZipFile(jar); src = z.read('assets/skyfront/models/entity/fpv.glb')
    fpvs = [('fpv_heavy', 106, 1.0, (170, 178, 140), 0.92), ('fpv_racer', 214, 1.0, (230, 236, 240), 1.05), ('fpv_longrange', 118, 0.7, (226, 220, 200), 1.0)]
    for name, hue, sat, tint, val in fpvs:
        js, blob = read_glb(src)
        im_bv = js['bufferViews'][js['images'][0]['bufferView']]
        png = blob[im_bv['byteOffset']:im_bv['byteOffset'] + im_bv['byteLength']]
        new = tint_texture(png, hue, sat, tint, val)
        js, blob = swap_texture(js, blob, new); write_glb(js, blob, f'{out}/models/entity/{name}.glb')
        Image.open(io.BytesIO(new)).save(f'{out}/textures/entity/{name}.png')
    print('ok')

if __name__ == '__main__':
    main()
